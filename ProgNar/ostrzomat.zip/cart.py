# cart.py - Moduł zarządzający wspólnym koszykiem

import tkinter as tk
from tkinter import ttk
from utils import format_price

class Cart:
    def __init__(self):
        """Inicjalizuje pusty koszyk."""
        self.items = []  # Lista pozycji w koszyku: [{name, params, quantity, price}, ...]

    def add_item(self, name, params, quantity, price):
        """
        Dodaje pozycję do koszyka.
        Args:
            name (str): Nazwa pozycji (np. 'Frezy kulowe').
            params (dict): Parametry pozycji (np. {'srednica': 10, 'ilosc_ostrzy': 4}).
            quantity (int): Ilość sztuk.
            price (float): Cena jednostkowa.
        """
        self.items.append({
            'name': name,
            'params': params,
            'quantity': quantity,
            'price': price
        })

    def remove_item(self, index):
        """
        Usuwa pozycję z koszyka.
        Args:
            index (int): Indeks pozycji do usunięcia.
        """
        if 0 <= index < len(self.items):
            self.items.pop(index)

    def get_total_price(self):
        """
        Oblicza całkowitą cenę w koszyku.
        Returns:
            float: Suma cen (cena jednostkowa * ilość dla każdej pozycji).
        """
        return sum(item['price'] * item['quantity'] for item in self.items)

    def show_cart(self, parent):
        """
        Wyświetla okno koszyka.
        Args:
            parent (tk.Tk): Główne okno aplikacji.
        """
        cart_window = tk.Toplevel(parent)
        cart_window.title("Koszyk")
        cart_window.geometry("600x400")

        # Tabela pozycji
        columns = ("Nazwa", "Parametry", "Ilość", "Cena jednostkowa", "Cena całkowita")
        tree = ttk.Treeview(cart_window, columns=columns, show="headings")
        tree.heading("Nazwa", text="Nazwa")
        tree.heading("Parametry", text="Parametry")
        tree.heading("Ilość", text="Ilość")
        tree.heading("Cena jednostkowa", text="Cena jednostkowa")
        tree.heading("Cena całkowita", text="Cena całkowita")
        tree.pack(fill=tk.BOTH, expand=True)

        # Wypełnianie tabeli
        for idx, item in enumerate(self.items):
            params_str = ", ".join(f"{k}: {v}" for k, v in item['params'].items())
            total_item_price = item['price'] * item['quantity']
            tree.insert("", tk.END, values=(
                item['name'],
                params_str,
                item['quantity'],
                format_price(item['price']),
                format_price(total_item_price)
            ))

        # Przycisk usuwania pozycji
        def delete_selected():
            selected = tree.selection()
            if selected:
                index = tree.index(selected[0])
                self.remove_item(index)
                tree.delete(selected[0])
                update_total_label()

        # Przycisk zamykania okna
        def close_window():
            cart_window.destroy()

        # Etykieta z sumą
        total_price = self.get_total_price()
        total_label = tk.Label(cart_window, text=f"Całkowita cena: {format_price(total_price)}")
        total_label.pack(pady=10)

        def update_total_label():
            total_price = self.get_total_price()
            total_label.config(text=f"Całkowita cena: {format_price(total_price)}")

        # Przyciski
        button_frame = tk.Frame(cart_window)
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="Usuń wybraną pozycję", command=delete_selected).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Zamknij", command=close_window).pack(side=tk.LEFT, padx=5)