# main.py - Główny moduł aplikacji z menu głównym

import tkinter as tk
from cart import Cart
from frezy_menu import FrezyMenu
from wiertla_menu import WiertlaMenu
from pozostale_menu import PozostaleMenu
from uslugi_menu import UslugiMenu

class ToolPricingApp:
    """Główna klasa aplikacji z menu głównym."""
    def __init__(self, root):
        """
        Inicjalizuje aplikację.
        Args:
            root (tk.Tk): Główne okno aplikacji.
        """
        self.root = root
        self.root.title("Kalkulator cen narzędziowy")
        self.root.geometry("300x500")

        # Inicjalizacja wspólnego koszyka
        self.cart = Cart()

        # Tytuł
        tk.Label(self.root, text="Kalkulator cenowy", font=("Arial", 18)).pack(pady=20)

        # Przyciski menu
        tk.Button(self.root, text="Frezy", font=("Arial", 14), command=self.show_frezy_menu).pack(pady=10)
        tk.Button(self.root, text="Wiertła", font=("Arial", 14), command=self.show_wiertla_menu).pack(pady=10)
        tk.Button(self.root, text="Pozostałe", font=("Arial", 14), command=self.show_pozostale_menu).pack(pady=10)
        tk.Button(self.root, text="Usługi", font=("Arial", 14), command=self.show_uslugi_menu).pack(pady=10)
        tk.Button(self.root, text="Koszyk", font=("Arial", 14), command=self.show_cart).pack(pady=10)
        tk.Button(self.root, text="Wyjście", font=("Arial", 14), command=self.root.quit).pack(pady=10)

    def show_frezy_menu(self):
        """Otwiera menu frezów."""
        FrezyMenu(self.root, self.cart)

    def show_wiertla_menu(self):
        """Otwiera menu wierteł."""
        WiertlaMenu(self.root, self.cart)

    def show_pozostale_menu(self):
        """Otwiera menu pozostałych pozycji."""
        PozostaleMenu(self.root, self.cart)

    def show_uslugi_menu(self):
        """Otwiera menu usług."""
        UslugiMenu(self.root, self.cart)

    def show_cart(self):
        """Otwiera okno koszyka."""
        self.cart.show_cart(self.root)

if __name__ == "__main__":
    root = tk.Tk()
    app = ToolPricingApp(root)
    root.mainloop()